import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'movie-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
    private movies: Array<any>;
    private movie: any;

    constructor( private route: ActivatedRoute ){}

    ngOnInit(){
      let id = this.route.snapshot.params['id'];

      this.movies = [
          {
              id: 1,
              title: 'Avatar',
              director: 'J. Cameron',
              poster: 'http://images.affiches-et-posters.com//albums/3/47832/poster-film-avatar.jpg',
              releaseDate: '2010-06-12',
              rate: 4.12,
          },
          {
              id: 2,
              title: 'La totale',
              director: 'C. Zidi',
              poster: 'https://images-na.ssl-images-amazon.com/images/I/51SP49N80WL.jpg',
              releaseDate: '1991-06-12',
              rate: 2.28,
          },
          {
              id: 3,
              title: '60 seconde chrono',
              director: 'D. Sena',
              poster: 'http://fr.web.img2.acsta.net/c_215_290/medias/nmedia/00/02/12/73/affiche.jpg',
              releaseDate: '2000-04-12',
              rate: 3.8,
          },
      ];

      for( let movie of this.movies ){
          if( movie.id == id ){
              this.movie = movie;
          }
      }
    }

}
