import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListComponent } from '../component/list/list.component';
import { HoverDirective } from '../directive/hover.directive';

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    HoverDirective
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
