import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'movie-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
    private movies: Array<any>;

    constructor(){}

    ngOnInit(){
        this.movies = [
            {
                id: 1,
                title: 'Avatar',
                director: 'J. Cameron',
                poster: 'http://images.affiches-et-posters.com//albums/3/47832/poster-film-avatar.jpg',
                releaseDate: '2010-06-12',
            },
            {
                id: 2,
                title: 'La totale',
                director: 'C. Zidi',
                poster: 'https://images-na.ssl-images-amazon.com/images/I/51SP49N80WL.jpg',
                releaseDate: '1991-06-12',
            },
            {
                id: 3,
                title: '60 seconde chrono',
                director: 'D. Sena',
                poster: 'http://fr.web.img2.acsta.net/c_215_290/medias/nmedia/00/02/12/73/affiche.jpg',
                releaseDate: '2000-04-12',
            },
        ];
    }

    showTitle( title: string ){
        alert( title );
    }

}
